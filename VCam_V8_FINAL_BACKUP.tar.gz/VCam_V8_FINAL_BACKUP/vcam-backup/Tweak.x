#import "image_utils.h"

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <objc/message.h>
#import <objc/runtime.h>


#pragma mark - Debug Helper

static void VCamDebug(NSString *filename, NSString *text)
{
    @autoreleasepool {

        NSString *dir = @"/var/mobile/Media/VCam";

        [[NSFileManager defaultManager]
            createDirectoryAtPath:dir
            withIntermediateDirectories:YES
            attributes:nil
            error:nil];

        NSString *path =
            [dir stringByAppendingPathComponent:filename];

        NSError *error = nil;

        BOOL success =
            [text writeToFile:path
                   atomically:YES
                     encoding:NSUTF8StringEncoding
                        error:&error];

        NSLog(
            @"[VCAM] write %@ success=%d error=%@",
            path,
            success,
            error
        );
    }
}


#pragma mark - Constructor Test

__attribute__((constructor, used))
static void vcamLoaded(void)
{
    @autoreleasepool {
        NSError *error = nil;

        [@"VCAM CONSTRUCTOR WORKS\n"
            writeToFile:@"/tmp/vcam_constructor_test.txt"
            atomically:YES
            encoding:NSUTF8StringEncoding
            error:&error];

        NSLog(@"[VCAM] constructor error=%@", error);
    }
}

#pragma mark - BWNodeOutput Hook

%hook BWNodeOutput

- (void)emitSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    /*
     * 02:
     * Hook BWNodeOutput đã thực sự được gọi.
     *
     * Chỉ ghi một lần để tránh ghi file mỗi frame.
     */
    static dispatch_once_t hookOnce;

    dispatch_once(&hookOnce, ^{
        VCamDebug(
            @"02_hook.txt",
            @"BWNodeOutput HOOK OK\n"
        );
    });


    /*
     * Lấy mediaType.
     */
    unsigned int mediaType =
        ((unsigned int (*)(id, SEL))objc_msgSend)(
            self,
            sel_registerName("mediaType")
        );


    /*
     * Không phải video -> trả về pipeline gốc.
     */
    if (mediaType != 'vide') {

        %orig(sampleBuffer);
        return;
    }


    /*
     * 03:
     * Xác nhận video stream.
     */
    static dispatch_once_t videoOnce;

    dispatch_once(&videoOnce, ^{
        VCamDebug(
            @"03_video.txt",
            @"mediaType == vide OK\n"
        );
    });


    /*
     * Lấy CVPixelBuffer.
     */
    CVPixelBufferRef originalImageBuffer =
        CMSampleBufferGetImageBuffer(sampleBuffer);


    if (originalImageBuffer == NULL) {

        %orig(sampleBuffer);
        return;
    }


    /*
     * Lấy kích thước buffer.
     */
    size_t width =
        CVPixelBufferGetWidth(originalImageBuffer);

    size_t height =
        CVPixelBufferGetHeight(originalImageBuffer);


    /*
     * 04:
     * Xác nhận lấy được CVPixelBuffer.
     */
    static dispatch_once_t bufferOnce;

    dispatch_once(&bufferOnce, ^{

        NSString *info =
            [NSString stringWithFormat:
                @"CVPixelBuffer OK SIZE=%zux%zu\n",
                width,
                height
            ];

        VCamDebug(
            @"04_buffer.txt",
            info
        );
    });


    /*
     * Đọc RotationDegrees nếu stream có metadata này.
     */
    int rotationDegrees = 0;

    CFTypeRef rotationAttachment =
        CMGetAttachment(
            sampleBuffer,
            CFSTR("RotationDegrees"),
            NULL
        );


    if (rotationAttachment != NULL &&
        CFGetTypeID(rotationAttachment) ==
            CFNumberGetTypeID()) {

        CFNumberGetValue(
            (CFNumberRef)rotationAttachment,
            kCFNumberIntType,
            &rotationDegrees
        );
    }


    /*
     * Chỉ ghi thông tin rotation lần đầu.
     */
    static dispatch_once_t rotationOnce;

    dispatch_once(&rotationOnce, ^{

        NSString *rotationInfo =
            [NSString stringWithFormat:
                @"SIZE=%zux%zu RotationDegrees=%d\n",
                width,
                height,
                rotationDegrees
            ];

        VCamDebug(
            @"rotation.txt",
            rotationInfo
        );
    });


    /*
     * Load replacement media đúng một lần.
     */
    static dispatch_once_t mediaOnce;

    dispatch_once(&mediaOnce, ^{

        VCamDebug(
            @"05_before_load.txt",
            @"Calling loadReplacementMedia\n"
        );


        loadReplacementMedia();


        VCamDebug(
            @"06_after_load.txt",
            @"loadReplacementMedia returned\n"
        );
    });


    /*
     * Render replacement vào buffer.
     */
    @try {

        CVReturn lockResult =
            CVPixelBufferLockBaseAddress(
                originalImageBuffer,
                0
            );


        if (lockResult == kCVReturnSuccess) {

            /*
             * Marker lock chỉ cần ghi một lần.
             */
            static dispatch_once_t lockOnce;

            dispatch_once(&lockOnce, ^{
                VCamDebug(
                    @"07_buffer_locked.txt",
                    @"CVPixelBuffer locked OK\n"
                );
            });


            /*
             * Hàm render VCam.
             */
            drawReplacementOntoBuffer(
                originalImageBuffer,
                rotationDegrees
            );


            /*
             * Nếu tới đây => hàm render đã return.
             */
            static dispatch_once_t renderOnce;

            dispatch_once(&renderOnce, ^{
                VCamDebug(
                    @"08_render_returned.txt",
                    @"drawReplacementOntoBuffer returned\n"
                );
            });


            CVPixelBufferUnlockBaseAddress(
                originalImageBuffer,
                0
            );


            static dispatch_once_t unlockOnce;

            dispatch_once(&unlockOnce, ^{
                VCamDebug(
                    @"09_buffer_unlocked.txt",
                    @"CVPixelBuffer unlocked OK\n"
                );
            });
        }
        else {

            static dispatch_once_t lockErrorOnce;

            dispatch_once(&lockErrorOnce, ^{

                NSString *lockError =
                    [NSString stringWithFormat:
                        @"CVPixelBufferLockBaseAddress ERROR=%d\n",
                        lockResult
                    ];

                VCamDebug(
                    @"07_lock_error.txt",
                    lockError
                );
            });
        }
    }

    @catch (NSException *exception) {

        static dispatch_once_t exceptionOnce;

        dispatch_once(&exceptionOnce, ^{

            NSString *error =
                [NSString stringWithFormat:
                    @"Exception=%@\nReason=%@\n",
                    exception.name,
                    exception.reason
                ];

            VCamDebug(
                @"99_exception.txt",
                error
            );
        });
    }


    /*
     * Tiếp tục pipeline camera gốc.
     */
    %orig(sampleBuffer);
}

%end
