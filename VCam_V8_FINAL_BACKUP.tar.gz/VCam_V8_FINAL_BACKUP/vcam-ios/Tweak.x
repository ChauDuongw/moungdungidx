#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreImage/CoreImage.h>

#import <objc/runtime.h>
#import <objc/message.h>

#include <dispatch/dispatch.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

extern void MSHookMessageEx(Class cls, SEL sel, IMP imp, IMP *result);

static NSString *const VCamImagePath =
    @"/var/mobile/Media/VCam/test.png";

static const char *VCamLogPath =
    "/var/mobile/Media/VCam/vcam.log";

static void (*VCamOriginalEmit)(
    id,
    SEL,
    CMSampleBufferRef
) = NULL;

static BOOL VCamHookInstalled = NO;
static BOOL VCamWaitingLogged = NO;

static dispatch_queue_t VCamHookQueue;

static NSObject *VCamLock = nil;
static CIContext *VCamContext = nil;
static CGImageRef VCamImage = NULL;

static unsigned long VCamFrameCounter = 0;

static void VCamLog(const char *text)
{
    mkdir("/var/mobile/Media/VCam", 0755);

    int fd = open(
        VCamLogPath,
        O_CREAT | O_WRONLY | O_APPEND,
        0644
    );

    if (fd < 0)
        return;

    write(fd, text, strlen(text));
    write(fd, "\n", 1);

    close(fd);
}

static BOOL VCamLoadImage(void)
{
    @autoreleasepool {

        UIImage *image =
            [UIImage imageWithContentsOfFile:VCamImagePath];

        if (!image || !image.CGImage) {
            VCamLog("IMAGE_NOT_FOUND");
            return NO;
        }

        @synchronized (VCamLock) {

            if (VCamImage) {
                CGImageRelease(VCamImage);
                VCamImage = NULL;
            }

            VCamImage = CGImageRetain(image.CGImage);

            if (!VCamContext) {
                VCamContext =
                    [CIContext contextWithOptions:nil];
            }
        }

        VCamLog("IMAGE_LOADED");

        return YES;
    }
}

static void VCamRender(
    CVPixelBufferRef pixelBuffer
)
{
    if (!pixelBuffer)
        return;

    CGImageRef image = NULL;
    CIContext *context = nil;

    @synchronized (VCamLock) {

        if (VCamImage) {
            image = CGImageRetain(VCamImage);
        }

        context = VCamContext;
    }

    if (!image || !context) {
        if (image)
            CGImageRelease(image);

        return;
    }

    @autoreleasepool {

        CIImage *source =
            [CIImage imageWithCGImage:image];

        size_t targetWidth =
            CVPixelBufferGetWidth(pixelBuffer);

        size_t targetHeight =
            CVPixelBufferGetHeight(pixelBuffer);

        CGRect extent = source.extent;

        CGFloat scaleX =
            (CGFloat)targetWidth /
            extent.size.width;

        CGFloat scaleY =
            (CGFloat)targetHeight /
            extent.size.height;

        // Aspect-fill
        CGFloat scale = MAX(scaleX, scaleY);

        CIImage *scaled =
            [source imageByApplyingTransform:
                CGAffineTransformMakeScale(
                    scale,
                    scale
                )
            ];

        CGRect scaledExtent =
            scaled.extent;

        CGFloat offsetX =
            ((CGFloat)targetWidth -
             scaledExtent.size.width) / 2.0;

        CGFloat offsetY =
            ((CGFloat)targetHeight -
             scaledExtent.size.height) / 2.0;

        CIImage *finalImage =
            [scaled imageByApplyingTransform:
                CGAffineTransformMakeTranslation(
                    offsetX,
                    offsetY
                )
            ];

        CVPixelBufferLockBaseAddress(
            pixelBuffer,
            0
        );

        [context
            render:finalImage
            toCVPixelBuffer:pixelBuffer];

        CVPixelBufferUnlockBaseAddress(
            pixelBuffer,
            0
        );

        static dispatch_once_t renderOnce;

        dispatch_once(&renderOnce, ^{
            VCamLog("RENDER_OK");
        });
    }

    CGImageRelease(image);
}

static void VCamEmitSampleBuffer(
    id self,
    SEL _cmd,
    CMSampleBufferRef sampleBuffer
)
{
    unsigned int mediaType = 0;

    SEL mediaSelector =
        sel_registerName("mediaType");

    if ([self respondsToSelector:mediaSelector]) {

        mediaType =
            ((unsigned int (*)(id, SEL))objc_msgSend)(
                self,
                mediaSelector
            );
    }

    if (mediaType == 'vide') {

        static dispatch_once_t frameOnce;

        dispatch_once(&frameOnce, ^{
            VCamLog("VIDEO_FRAME");
        });

        CVPixelBufferRef buffer =
            CMSampleBufferGetImageBuffer(
                sampleBuffer
            );

        if (buffer) {

            BOOL imageReady = NO;

            @synchronized (VCamLock) {
                imageReady =
                    (VCamImage != NULL);
            }

            /*
             * Không dùng dispatch_once.
             * Nếu ảnh chưa tồn tại thì retry.
             */
            if (!imageReady) {

                VCamFrameCounter++;

                if (VCamFrameCounter == 1 ||
                    VCamFrameCounter % 30 == 0) {

                    VCamLoadImage();
                }
            }

            @synchronized (VCamLock) {
                imageReady =
                    (VCamImage != NULL);
            }

            if (imageReady) {
                VCamRender(buffer);
            }
        }
    }

    if (VCamOriginalEmit) {
        VCamOriginalEmit(
            self,
            _cmd,
            sampleBuffer
        );
    }
}

static void VCamTryInstallHook(void)
{
    if (VCamHookInstalled)
        return;

    Class cls =
        objc_getClass("BWNodeOutput");

    SEL selector =
        sel_registerName(
            "emitSampleBuffer:"
        );

    Method method = NULL;

    if (cls) {
        method =
            class_getInstanceMethod(
                cls,
                selector
            );
    }

    if (cls && method) {

        MSHookMessageEx(
            cls,
            selector,
            (IMP)VCamEmitSampleBuffer,
            (IMP *)&VCamOriginalEmit
        );

        VCamHookInstalled = YES;

        VCamLog("HOOK_INSTALLED");

        return;
    }

    if (!VCamWaitingLogged) {
        VCamWaitingLogged = YES;
        VCamLog("WAITING_BWNODEOUTPUT");
    }

    /*
     * RootHide có thể inject trước khi
     * BWNodeOutput được load.
     *
     * Chờ và thử lại.
     */
    dispatch_after(
        dispatch_time(
            DISPATCH_TIME_NOW,
            500 * NSEC_PER_MSEC
        ),
        VCamHookQueue,
        ^{
            VCamTryInstallHook();
        }
    );
}

__attribute__((constructor))
static void VCamStart(void)
{
    @autoreleasepool {

        mkdir(
            "/var/mobile/Media/VCam",
            0755
        );

        VCamLog("CTOR");

        VCamLock =
            [[NSObject alloc] init];

        VCamHookQueue =
            dispatch_queue_create(
                "com.vcam.roothide.hook",
                DISPATCH_QUEUE_SERIAL
            );

        dispatch_async(
            VCamHookQueue,
            ^{
                VCamTryInstallHook();
            }
        );
    }
}
