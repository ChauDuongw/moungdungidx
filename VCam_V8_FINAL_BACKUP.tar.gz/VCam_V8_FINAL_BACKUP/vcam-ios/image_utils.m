#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreImage/CoreImage.h>
#import <UIKit/UIKit.h>
#import <math.h>

#import "image_utils.h"

// File anh/video thay the
static NSString *const kReplacementMediaPath = @"/var/mobile/Media/VCam/test.png";
typedef enum {
    VCamModeNone = 0,
    VCamModeImage,
    VCamModeVideo
} VCamMode;

static VCamMode currentMode = VCamModeNone;

static CGImageRef replacementImage = NULL;

static NSMutableArray *videoFrames = nil;
static NSUInteger currentFrameIndex = 0;

static CIContext *sharedCIContext = nil;
static NSObject *vcamLock = nil;


// ============================================================
// LOAD REPLACEMENT MEDIA
// ============================================================

void loadReplacementMedia(void) {

    if (!vcamLock) {
        vcamLock = [[NSObject alloc] init];
    }

    if (![[NSFileManager defaultManager]
            fileExistsAtPath:kReplacementMediaPath]) {

        return;
    }

    NSString *extension =
        [[kReplacementMediaPath pathExtension] lowercaseString];


    // ========================================================
    // IMAGE
    // ========================================================

    if ([extension isEqualToString:@"png"] ||
        [extension isEqualToString:@"jpg"] ||
        [extension isEqualToString:@"jpeg"]) {

        UIImage *image =
            [UIImage imageWithContentsOfFile:kReplacementMediaPath];

        if (image && image.CGImage) {

            if (replacementImage != NULL) {
                CGImageRelease(replacementImage);
                replacementImage = NULL;
            }

            replacementImage =
                CGImageRetain(image.CGImage);

            currentMode = VCamModeImage;
        }
    }


    // ========================================================
    // VIDEO FILE
    // ========================================================

    else if ([extension isEqualToString:@"mp4"] ||
             [extension isEqualToString:@"mov"]) {

        NSURL *videoURL =
            [NSURL fileURLWithPath:kReplacementMediaPath];

        AVAsset *asset =
            [AVAsset assetWithURL:videoURL];

        NSError *error = nil;

        AVAssetReader *assetReader =
            [[AVAssetReader alloc]
                initWithAsset:asset
                error:&error];

        if (error || !assetReader) {
            return;
        }

        NSArray *videoTracks =
            [asset tracksWithMediaType:AVMediaTypeVideo];

        if (videoTracks.count == 0) {
            return;
        }

        AVAssetTrack *videoTrack =
            videoTracks[0];

        NSDictionary *outputSettings = @{
            (NSString *)kCVPixelBufferPixelFormatTypeKey:
                @(kCVPixelFormatType_32BGRA)
        };

        AVAssetReaderTrackOutput *videoOutput =
            [[AVAssetReaderTrackOutput alloc]
                initWithTrack:videoTrack
                outputSettings:outputSettings];

        videoOutput.alwaysCopiesSampleData = NO;

        if (![assetReader canAddOutput:videoOutput]) {
            return;
        }

        [assetReader addOutput:videoOutput];

        if (![assetReader startReading]) {
            return;
        }

        videoFrames =
            [[NSMutableArray alloc] init];

        int frameCount = 0;
        int maxFrames = 60;

        while (assetReader.status ==
                   AVAssetReaderStatusReading &&
               frameCount < maxFrames) {

            CMSampleBufferRef sampleBuffer =
                [videoOutput copyNextSampleBuffer];

            if (sampleBuffer == NULL) {
                break;
            }

            CVPixelBufferRef pixelBuffer =
                CMSampleBufferGetImageBuffer(sampleBuffer);

            if (pixelBuffer) {

                CVPixelBufferRetain(pixelBuffer);

                [videoFrames
                    addObject:(__bridge id)pixelBuffer];

                frameCount++;
            }

            CFRelease(sampleBuffer);
        }

        if (frameCount > 0) {
            currentMode = VCamModeVideo;
        }

        [assetReader cancelReading];
    }


    // ========================================================
    // CORE IMAGE CONTEXT
    // ========================================================

    if (sharedCIContext == nil) {
        sharedCIContext = [CIContext context];
    }
}


// ============================================================
// DRAW REPLACEMENT ONTO CAMERA BUFFER
// ============================================================

void drawReplacementOntoBuffer(
    CVPixelBufferRef targetBuffer,
    int rotationDegrees
) {

    // Hien tai KHONG dung rotationDegrees de xoay toan bo pipeline.
    (void)rotationDegrees;

    if (targetBuffer == NULL) {
        return;
    }

    @synchronized(vcamLock) {

        CIImage *replacementCIImage = nil;


        // ====================================================
        // STATIC IMAGE
        // ====================================================

        if (currentMode == VCamModeImage) {

            if (replacementImage != NULL) {

                replacementCIImage =
                    [CIImage imageWithCGImage:replacementImage];
            }
        }


        // ====================================================
        // VIDEO REPLACEMENT
        // ====================================================

        else if (currentMode == VCamModeVideo) {

            if (videoFrames.count > 0) {

                CVPixelBufferRef videoFrame =
                    (__bridge CVPixelBufferRef)
                        videoFrames[currentFrameIndex];

                currentFrameIndex =
                    (currentFrameIndex + 1) %
                    videoFrames.count;

                replacementCIImage =
                    [CIImage imageWithCVPixelBuffer:videoFrame];
            }
        }


        if (!replacementCIImage) {
            return;
        }


        // ====================================================
        // TARGET BUFFER SIZE
        // ====================================================

        CGFloat targetWidth =
            (CGFloat)CVPixelBufferGetWidth(targetBuffer);

        CGFloat targetHeight =
            (CGFloat)CVPixelBufferGetHeight(targetBuffer);


        // ====================================================
        // PHOTO FIX
        //
        // Log:
        // 4032x3024 = full resolution still-photo buffer.
        //
        // Phan nay da test va Photo da dung.
        // GIU NGUYEN.
        // ====================================================

        if (targetWidth == 4032 &&
            targetHeight == 3024) {

            CGAffineTransform rotate =
                CGAffineTransformMakeRotation(M_PI_2);

            replacementCIImage =
                [replacementCIImage
                    imageByApplyingTransform:rotate];

            CGRect rotatedExtent =
                replacementCIImage.extent;

            CGAffineTransform normalize =
                CGAffineTransformMakeTranslation(
                    -rotatedExtent.origin.x,
                    -rotatedExtent.origin.y
                );

            replacementCIImage =
                [replacementCIImage
                    imageByApplyingTransform:normalize];
        }


        // ====================================================
        // VIDEO TEST
        //
        // Log khi REC:
        //
        // 1080x1920 -> RotationDegrees = 90
        // 1920x1080 -> khong RotationDegrees
        // 2304x1296 -> khong RotationDegrees
        //
        // Hien tai CHI TEST 1920x1080.
        //
        // Khong them 2304x1296 o buoc nay.
        // ====================================================

        else if (targetWidth == 1920 &&
                 targetHeight == 1080) {

            CGAffineTransform rotate =
                CGAffineTransformMakeRotation(M_PI_2);

            replacementCIImage =
                [replacementCIImage
                    imageByApplyingTransform:rotate];

            CGRect rotatedExtent =
                replacementCIImage.extent;

            CGAffineTransform normalize =
                CGAffineTransformMakeTranslation(
                    -rotatedExtent.origin.x,
                    -rotatedExtent.origin.y
                );

            replacementCIImage =
                [replacementCIImage
                    imageByApplyingTransform:normalize];
        }


        // ====================================================
        // ASPECT FILL
        // ====================================================

        CGRect replacementExtent =
            replacementCIImage.extent;

        if (replacementExtent.size.width <= 0 ||
            replacementExtent.size.height <= 0) {

            return;
        }

        CGFloat scaleX =
            targetWidth /
            replacementExtent.size.width;

        CGFloat scaleY =
            targetHeight /
            replacementExtent.size.height;

        // MAX = aspect fill
        CGFloat scale =
            MAX(scaleX, scaleY);


        CGAffineTransform scaleTransform =
            CGAffineTransformMakeScale(
                scale,
                scale
            );

        CIImage *scaledImage =
            [replacementCIImage
                imageByApplyingTransform:scaleTransform];


        // ====================================================
        // CENTER IMAGE
        // ====================================================

        CGRect scaledExtent =
            scaledImage.extent;

        CGFloat offsetX =
            (targetWidth -
             scaledExtent.size.width) / 2.0 -
            scaledExtent.origin.x;

        CGFloat offsetY =
            (targetHeight -
             scaledExtent.size.height) / 2.0 -
            scaledExtent.origin.y;


        CGAffineTransform translationTransform =
            CGAffineTransformMakeTranslation(
                offsetX,
                offsetY
            );


        CIImage *finalImage =
            [scaledImage
                imageByApplyingTransform:
                    translationTransform];


        // ====================================================
        // CROP TO EXACT TARGET SIZE
        // ====================================================

        finalImage =
            [finalImage imageByCroppingToRect:
                CGRectMake(
                    0,
                    0,
                    targetWidth,
                    targetHeight
                )
            ];


        // ====================================================
        // RENDER
        // ====================================================

        if (sharedCIContext) {

            [sharedCIContext
                render:finalImage
                toCVPixelBuffer:targetBuffer];
        }
    }
}
