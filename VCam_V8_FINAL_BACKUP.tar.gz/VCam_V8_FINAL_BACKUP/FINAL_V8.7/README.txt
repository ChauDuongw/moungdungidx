VCamMini V8.7 FINAL WORKING

Confirmed working:
- TCP image/video streaming
- VCam ON/OFF
- Color fix
- Photo orientation fix: 4032x3024
- Video orientation fix: 1920x1080
- RootHide / ElleKit
- mediaserverd injection

IMPORTANT:
com.test.vcammini_8.7.0-1+debug_iphoneos-arm64e.deb
is the known-working installation package.
