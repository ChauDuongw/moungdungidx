#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreImage/CoreImage.h>

#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <errno.h>


static CIContext *gContext = nil;
static CIImage *gImage = nil;
static pthread_mutex_t gImageLock = PTHREAD_MUTEX_INITIALIZER;
static BOOL gHasNetworkFrame = NO;
static volatile BOOL gVCamEnabled = NO;



static void WriteLog(NSString *text)
{
    const char *msg = [text UTF8String];

    int fd = open("/tmp/vcam_mini.log",
                  O_CREAT | O_WRONLY | O_APPEND,
                  0644);

    if (fd >= 0) {
        write(fd, msg, strlen(msg));
        write(fd, "\n", 1);
        close(fd);
    }
}

static BOOL LoadTestImage(void)
{
    static NSTimeInterval lastCheck = 0;
    static NSTimeInterval lastModified = -1;

    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];

    if (gImage && (now - lastCheck) < 0.10)
        return YES;

    lastCheck = now;

    NSString *path = @"/tmp/vcam_test.png";

    NSDictionary *attrs =
        [[NSFileManager defaultManager]
            attributesOfItemAtPath:path
                             error:nil];

    NSDate *modified = attrs[NSFileModificationDate];

    if (!modified)
        return gImage != nil;

    NSTimeInterval currentModified =
        [modified timeIntervalSinceReferenceDate];

    if (gImage && currentModified == lastModified)
        return YES;

    UIImage *image =
        [UIImage imageWithContentsOfFile:path];

    if (!image || !image.CGImage) {
        WriteLog(@"FRAME_RELOAD_FAILED");
        return gImage != nil;
    }

    gImage = [CIImage imageWithCGImage:image.CGImage];

    if (!gContext)
        gContext = [CIContext contextWithOptions:nil];

    lastModified = currentModified;

    WriteLog(
        [NSString stringWithFormat:
            @"FRAME_RELOADED %.0fx%.0f",
            gImage.extent.size.width,
            gImage.extent.size.height]
    );

    return YES;
}

static void RenderImage(CVPixelBufferRef buffer)
{
    if (!buffer) return;

    CIImage *localImage = nil;

    pthread_mutex_lock(&gImageLock);
    if (gImage)
        localImage = gImage;
    pthread_mutex_unlock(&gImageLock);

    if (!localImage) {
        LoadTestImage();

        pthread_mutex_lock(&gImageLock);
        if (gImage)
            localImage = gImage;
        pthread_mutex_unlock(&gImageLock);
    }

    if (!localImage) return;

    size_t width = CVPixelBufferGetWidth(buffer);
    size_t height = CVPixelBufferGetHeight(buffer);

    // ========================================================
    // V8.6 PHOTO FIX
    // Old working implementation:
    // 4032x3024 = full-resolution still-photo buffer.
    // Rotate replacement 90 degrees before aspect-fill.
    // ========================================================
    if (width == 4032 && height == 3024) {

        CGAffineTransform rotate =
            CGAffineTransformMakeRotation(M_PI_2);

        localImage =
            [localImage imageByApplyingTransform:rotate];

        CGRect rotatedExtent = localImage.extent;

        CGAffineTransform normalize =
            CGAffineTransformMakeTranslation(
                -rotatedExtent.origin.x,
                -rotatedExtent.origin.y
            );

        localImage =
            [localImage imageByApplyingTransform:normalize];

        static BOOL photoFixLogged = NO;
        if (!photoFixLogged) {
            photoFixLogged = YES;
            WriteLog(@"V86_PHOTO_FIX_4032x3024");
        }
    }

    // ========================================================
    // V8.7 VIDEO FIX
    // Old tested pipeline:
    // 1920x1080 -> rotate 90 degrees before aspect-fill.
    // ========================================================
    if (width == 1920 && height == 1080) {

        CGAffineTransform rotate =
            CGAffineTransformMakeRotation(M_PI_2);

        localImage =
            [localImage imageByApplyingTransform:rotate];

        CGRect rotatedExtent = localImage.extent;

        CGAffineTransform normalize =
            CGAffineTransformMakeTranslation(
                -rotatedExtent.origin.x,
                -rotatedExtent.origin.y
            );

        localImage =
            [localImage imageByApplyingTransform:normalize];

        static BOOL videoFixLogged = NO;
        if (!videoFixLogged) {
            videoFixLogged = YES;
            WriteLog(@"V87_VIDEO_FIX_1920x1080");
        }
    }

    CGRect src = localImage.extent;

    CGFloat sx = (CGFloat)width / src.size.width;
    CGFloat sy = (CGFloat)height / src.size.height;
    CGFloat scale = MAX(sx, sy);

    CIImage *scaled =
        [localImage imageByApplyingTransform:
            CGAffineTransformMakeScale(scale, scale)];

    CGRect e = scaled.extent;

    CGFloat tx =
        ((CGFloat)width - e.size.width) / 2.0 - e.origin.x;

    CGFloat ty =
        ((CGFloat)height - e.size.height) / 2.0 - e.origin.y;

    CIImage *finalImage =
        [scaled imageByApplyingTransform:
            CGAffineTransformMakeTranslation(tx, ty)];

    CGColorSpaceRef sRGB =
        CGColorSpaceCreateWithName(kCGColorSpaceSRGB);

    if (!sRGB)
        sRGB = CGColorSpaceCreateDeviceRGB();

    NSDictionary *attachments = @{
        (NSString *)kCVImageBufferYCbCrMatrixKey:
            (NSString *)kCVImageBufferYCbCrMatrix_ITU_R_601_4,

        (NSString *)kCVImageBufferColorPrimariesKey:
            (NSString *)kCVImageBufferColorPrimaries_ITU_R_709_2,

        (NSString *)kCVImageBufferTransferFunctionKey:
            (NSString *)kCVImageBufferTransferFunction_ITU_R_709_2
    };

    for (NSString *key in attachments) {
        CVBufferSetAttachment(
            buffer,
            (__bridge CFStringRef)key,
            (__bridge CFTypeRef)attachments[key],
            kCVAttachmentMode_ShouldPropagate
        );
    }

    [gContext render:finalImage
      toCVPixelBuffer:buffer
               bounds:CGRectMake(0, 0, width, height)
           colorSpace:sRGB];

    if (sRGB)
        CGColorSpaceRelease(sRGB);
}


static BOOL RecvExact(int fd, void *buffer, size_t length)
{
    uint8_t *p = (uint8_t *)buffer;
    size_t received = 0;

    while (received < length) {

        ssize_t n = recv(
            fd,
            p + received,
            length - received,
            0
        );

        if (n <= 0)
            return NO;

        received += (size_t)n;
    }

    return YES;
}


static void *VCamTCPServer(void *arg)
{
    @autoreleasepool {

        int serverFD =
            socket(AF_INET, SOCK_STREAM, 0);

        if (serverFD < 0) {
            WriteLog(@"TCP_SOCKET_FAILED");
            return NULL;
        }

        int yes = 1;

        setsockopt(
            serverFD,
            SOL_SOCKET,
            SO_REUSEADDR,
            &yes,
            sizeof(yes)
        );

        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));

        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(5555);

        if (bind(
                serverFD,
                (struct sockaddr *)&addr,
                sizeof(addr)
            ) < 0) {

            WriteLog(
                [NSString stringWithFormat:
                    @"TCP_BIND_FAILED errno=%d",
                    errno]
            );

            close(serverFD);
            return NULL;
        }

        if (listen(serverFD, 1) < 0) {
            WriteLog(@"TCP_LISTEN_FAILED");
            close(serverFD);
            return NULL;
        }

        WriteLog(@"TCP_V8_SERVER_5555");

        while (1) {

            struct sockaddr_in clientAddr;
            socklen_t clientLen =
                sizeof(clientAddr);

            int clientFD = accept(
                serverFD,
                (struct sockaddr *)&clientAddr,
                &clientLen
            );

            if (clientFD < 0)
                continue;

            char ip[INET_ADDRSTRLEN] = {0};

            inet_ntop(
                AF_INET,
                &clientAddr.sin_addr,
                ip,
                sizeof(ip)
            );

            WriteLog(
                [NSString stringWithFormat:
                    @"TCP_CLIENT_CONNECTED %s",
                    ip]
            );

            unsigned long frameCount = 0;

            while (1) {

                uint32_t networkLength = 0;

                if (!RecvExact(
                        clientFD,
                        &networkLength,
                        sizeof(networkLength)
                    ))
                    break;

                uint32_t frameLength =
                    ntohl(networkLength);

                // V8 control commands
                if (frameLength == 0xFFFFFFF1) {
                    gVCamEnabled = YES;
                    WriteLog(@"VCAM_ENABLED");
                    continue;
                }

                if (frameLength == 0xFFFFFFF0) {
                    gVCamEnabled = NO;
                    WriteLog(@"VCAM_DISABLED");
                    continue;
                }

                // Giới hạn 16 MB/frame
                if (frameLength == 0 ||
                    frameLength > 16 * 1024 * 1024) {

                    WriteLog(
                        [NSString stringWithFormat:
                            @"TCP_BAD_FRAME_SIZE %u",
                            frameLength]
                    );

                    break;
                }

                NSMutableData *data =
                    [NSMutableData
                        dataWithLength:frameLength];

                if (!RecvExact(
                        clientFD,
                        data.mutableBytes,
                        frameLength
                    ))
                    break;

                UIImage *image =
                    [UIImage imageWithData:data];

                if (!image || !image.CGImage) {
                    WriteLog(@"TCP_DECODE_FAILED");
                    continue;
                }

                CIImage *newImage =
                    [CIImage
                        imageWithCGImage:image.CGImage];

                pthread_mutex_lock(&gImageLock);

                gImage = newImage;
                gHasNetworkFrame = YES;

                if (!gContext)
                    gContext =
                        [CIContext contextWithOptions:nil];

                pthread_mutex_unlock(&gImageLock);

                frameCount++;

                // Không log mọi frame khi chạy video.
                if (frameCount == 1 ||
                    frameCount % 30 == 0) {

                    WriteLog(
                        [NSString stringWithFormat:
                            @"TCP_FRAME %lu %.0fx%.0f BYTES=%u",
                            frameCount,
                            newImage.extent.size.width,
                            newImage.extent.size.height,
                            frameLength]
                    );
                }
            }

            close(clientFD);

            WriteLog(@"TCP_CLIENT_DISCONNECTED");
        }
    }

    return NULL;
}


__attribute__((constructor))
static void VCamMiniLoaded(void)
{
    @autoreleasepool {
        WriteLog(@"VCAM_MINI_V83_COLOR_LOADED");

    pthread_t tcpThread;

    if (pthread_create(
            &tcpThread,
            NULL,
            VCamTCPServer,
            NULL
        ) == 0) {

        pthread_detach(tcpThread);

    } else {
        WriteLog(@"TCP_THREAD_FAILED");
    }
    }
}

%hook BWNodeOutput

- (void)emitSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    // OFF = camera thật, không render VCam.
    if (!gVCamEnabled) {
        %orig;
        return;
    }

    if (sampleBuffer) {

        CVPixelBufferRef buffer =
            CMSampleBufferGetImageBuffer(sampleBuffer);

        if (buffer) {

            static BOOL logged = NO;

            if (!logged) {
                logged = YES;

                OSType format =
                    CVPixelBufferGetPixelFormatType(buffer);

                WriteLog(
                    [NSString stringWithFormat:
                        @"BUFFER %zux%zu FORMAT=%u PLANAR=%d",
                        CVPixelBufferGetWidth(buffer),
                        CVPixelBufferGetHeight(buffer),
                        (unsigned int)format,
                        CVPixelBufferIsPlanar(buffer)]
                );
            }

            RenderImage(buffer);
        }
    }

    %orig;
}

%end
