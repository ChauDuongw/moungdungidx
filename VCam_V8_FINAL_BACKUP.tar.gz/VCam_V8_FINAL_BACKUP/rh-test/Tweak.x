#import <Foundation/Foundation.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

__attribute__((constructor))
static void RHTestLoaded(void)
{
    const char *msg = "ROOT_HIDE_TEST_LOADED\n";

    int fd = open(
        "/tmp/rh_test_loaded.txt",
        O_CREAT | O_WRONLY | O_TRUNC,
        0644
    );

    if (fd >= 0) {
        write(fd, msg, strlen(msg));
        close(fd);
    }
}
